import ProjectController from './ProjectController'
import ResourceController from './ResourceController'
import SkillController from './SkillController'
import ExperienceController from './ExperienceController'
import Settings from './Settings'
const Controllers = {
    ProjectController: Object.assign(ProjectController, ProjectController),
ResourceController: Object.assign(ResourceController, ResourceController),
SkillController: Object.assign(SkillController, SkillController),
ExperienceController: Object.assign(ExperienceController, ExperienceController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers