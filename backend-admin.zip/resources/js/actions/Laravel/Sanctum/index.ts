import Http from './Http'
const Sanctum = {
    Http: Object.assign(Http, Http),
}

export default Sanctum